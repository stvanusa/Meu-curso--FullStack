// script.js

document.addEventListener('DOMContentLoaded', () => {
    // Seleciona os elementos necessários
    const btnAnterior = document.getElementById('btnAnterior');
    const btnProximo = document.getElementById('btnProximo');
    const slides = document.querySelectorAll('.slide-conteiner'); // Seleciona todos os contêineres de slides
    let index = 0; // Índice do slide atual

    // Função para atualizar a visibilidade dos slides
    function atualizarSlides() {
        slides.forEach((slide, i) => {
            slide.style.display = i === index ? 'block' : 'none'; // Exibe apenas o slide atual
        });
    }

    // Função para ir para o slide anterior
    btnAnterior.addEventListener('click', () => {
        index = (index > 0) ? index - 1 : slides.length - 1; // Move para o slide anterior ou vai para o último slide se estiver no primeiro
        atualizarSlides();
    });

    // Função para ir para o slide próximo
    btnProximo.addEventListener('click', () => {
        index = (index < slides.length - 1) ? index + 1 : 0; // Move para o slide próximo ou volta para o primeiro slide se estiver no último
        atualizarSlides();
    });

    // Inicializa a visualização com o primeiro slide
    atualizarSlides();
});